var array=[
[0,0,0],
[0,0,0],
[0,0,0]
];
var turno=true;
function Gioco(n){
    let riga=Math.floor(n/3);
    let colonna=n%3;
    let str="";
    let vinto=false;
    if(turno){
        array[riga][colonna]=1;
        document.getElementById(n).disabled=true;
        document.getElementById(n).value="X";
        turno=false;
    }
    else{
        array[riga][colonna]=2;
        document.getElementById(n).disabled=true;
        document.getElementById(n).value="O";
        turno=true;
    }
    console.log(array.join(", "));
    
    vinto=VerificaRiga();
    vinto=VerificaColonna();
    vinto=VerificaDiagonale();
    if(vinto){
        if(turno){
            str="Ha vinto giocatore X";
        }
        else{
            str="Ha vinto giocatore O";
        }
        document.getElementById("risp")=str;
    }
}

function VerificaRiga(){;
    for(let i=0;i<3;i++){
        if(array[i][0]==array[i][1]==array[i][2] && array[i][0]!=0){
            for(let j=0;j<3;j++){
                num=i*3+j;
                document.getElementById(num).style.backgroundColor="rgb(72, 255, 81);";
            }
            return true;
        }
    }
    return false;
}

function VerificaColonna(){
    for(let i=0;i<3;i++){
        if(array[0][i]==array[1][i]==array[2][i] && array[0][i]!=0){
            for(let j=0;j<3;j++){
                num=j*3+i;
                document.getElementById(num).style.backgroundColor="rgb(72, 255, 81);";
            }
        return true;
        }
    }
    return false;
}

function VerificaDiagonale(){

}