﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bertoldo_VerificaOOP
{
    public enum tipoUtente
    {
        Studente,
        Docente,
        Esterno
    }
    internal class CPrestito
    {
        

        private int idPrestito;
        private string titoloLibro;
        private tipoUtente tipologiaUtente;
        private int giorniPrestito;
        private DateTime dataInizio;

        public CPrestito(){
            titoloLibro = "";
            tipologiaUtente = (tipoUtente)0;
            giorniPrestito = 0;
            dataInizio = DateTime.Now;
        }

        public CPrestito(string TitoloLibro, tipoUtente TipologiaUtente, int GiorniPrestito, DateTime DataInizio) { 
            titoloLibro = TitoloLibro;
            tipologiaUtente = TipologiaUtente;
            giorniPrestito = GiorniPrestito;
            dataInizio = DataInizio;
        }

        public DateTime CalcolaDataScadenza()
        {
           DateTime fine = dataInizio.AddDays(giorniPrestito);
           return fine;
        }

        public string ToString()
        {
            return $"ID : {idPrestito}\nTITOLO: {titoloLibro}\nTIPO UTENTE : {tipologiaUtente}\nGIORNI PRESTITO: {giorniPrestito}\nDATA INIZIO PRESTITO: {dataInizio.ToShortDateString()}";
        }

        public int GiorniPrestito
        {
            get { return giorniPrestito; }
            set
            {
                giorniPrestito = value;
            }
        }

        public string Titololibro
        {
            get { return titoloLibro; }
            set
            {
                titoloLibro = value;
            }
        }

        public tipoUtente TipologiaUtente
        {
            get { return tipologiaUtente; }
            set
            {
                tipologiaUtente = value;
            }
        }

        public int IdPrestito
        {
            get { return idPrestito;  }
            set
            {
                idPrestito = value;
            }
        }
    }
}
