﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bertoldo_VerificaOOP
{
    internal class CBiblioteca
    {
        private int count = 0;
        private List<CPrestito> prestiti;
        private string nomeBiblioteca;
        private string indirizzo;

        public CBiblioteca() //costruttore di default
        {
            prestiti = new List<CPrestito>();
            nomeBiblioteca = "";
            indirizzo = ""; 
        }

        public CBiblioteca(List<CPrestito> Prestiti, string NomeBiblioteca, string Indirizzo) //costruttore parametrizzato
        {
            prestiti = Prestiti;
            nomeBiblioteca = NomeBiblioteca;
            indirizzo = Indirizzo;
        }

        public void AggiungiPrestito(CPrestito p) //funzione per aggiungere un prestito
        {
            
            if (p.GiorniPrestito <= 0)
            {
                throw new Exception("ERRORE : I giorni di prestito devono essere positivi\n");
            }
            else
            {
                p.IdPrestito = count; //assegno l'id in base alla creazione del libro se è valido
                count++; 
                prestiti.Add(p);
            }
                
        }

        public void RestituisciLibro(int idPrestito)
        {
            prestiti.RemoveAt(idPrestito); //rimuovo dalla lista il libro con id richiesto
        }

        public string CercaPrestitoPerLibro(string Titolo)
        {
            string str = "";
            foreach(var i in prestiti) //cerco i prestiti per libro
            {
                if(i.Titololibro == Titolo)
                {
                    str += i.ToString()+"\n";
                }
            }
            if (str == "") str = "Prestiti non trovati per questo libro";//in caso nmon ci siano prestiti per un determinato libro
            return str; 
        }

        public double DurataMediaPrestiti() //calcolo la durata media dei prestiti con variabile di tipo double
        {
            double media = 0;
            foreach(var i in prestiti)
            {
                media += i.GiorniPrestito;
            }
            media /= prestiti.Count;
            return media;
        }

        public string PrestitiInRitardo() //restituisco i pretiti in  ritardo
        {
            string str = "";
            foreach (var i in prestiti)
            {
                if (i.CalcolaDataScadenza() < DateTime.Now) str += i.ToString();
            }
            if (str == "") str = "Non ci sono prestiti in ritardo";
            return str;
        }

        public int[] ContaprestitiPerCategoria() //restituisco un array con i prestiti per categoria
        {
            int[] valori = new int[3];
            foreach(CPrestito i in prestiti)
            {
                switch (i.TipologiaUtente)
                {
                    case tipoUtente.Studente:
                        valori[0]++; //aumento il valore della cella di array dedicata ai prestiti di tipo Studente
                        break;
                    case tipoUtente.Docente:
                        valori[1]++;
                        break;
                    case tipoUtente.Esterno:
                        valori[2]++;
                        break;
                }
            }
            return valori;
        }

        public string LibroPiuRichiesto() //restituisco il titolo del libro più richiesto
        {
            int id = 0;
            int[] libri = new int[prestiti.Count];
            string[] titoli = new string[prestiti.Count];
            foreach(var i in prestiti)  //utilizzo foreach per girare su tutti i prestiti
            { 
                if (titoli.Contains(i.Titololibro)) //se il titolo del libro in prestito esiste già lo cerco e aggiungo nell'array corrispondente "1" per aumentare il counter di prestiti per ogni titolo
                {
                    for (int l = 0; l < prestiti.Count; l++)
                    {
                        if (i.Titololibro == titoli[l]) libri[l]++;
                    }
                }
                else
                {
                    titoli[id] = i.Titololibro;
                    libri[id] = 1;
                    id++;
                }
            }
            int max = 0;
            for(int i = 1; i < libri.Length; i++)
            {
                if (libri[max] < libri[i]) max = i;
            }
            return titoli[max]; //restituisco il titolo del libro più richiesto
        }
    }
}
