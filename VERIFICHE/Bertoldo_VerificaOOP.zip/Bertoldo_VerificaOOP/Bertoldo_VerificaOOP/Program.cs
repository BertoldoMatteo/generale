﻿namespace Bertoldo_VerificaOOP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CBiblioteca biblioteca = new CBiblioteca();
            try 
            {
                biblioteca.AggiungiPrestito(new CPrestito("Inferno", tipoUtente.Studente, 34, DateTime.Now));
            }
            catch(Exception ex) //utilizzo il catch per verificare se è stata lanciata un'eccezione nel try e in caso stampo il messaggio dell'eccezione
            {
                Console.WriteLine(ex.Message);
            }

            try
            {
                biblioteca.AggiungiPrestito(new CPrestito("Albert Einstein", tipoUtente.Esterno, 21, DateTime.Now));
            }
            catch (Exception ex)//"acchiappo" tutte le eccezioni
            {
                Console.WriteLine(ex.Message);
            }

            try {
                biblioteca.AggiungiPrestito(new CPrestito("Paradiso", tipoUtente.Docente, 2, DateTime.Now));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            try
            {
                biblioteca.AggiungiPrestito(new CPrestito("La Bell Addormentata", tipoUtente.Esterno, 100, DateTime.Now));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            try
            {
                biblioteca.AggiungiPrestito(new CPrestito("Albert Einstein", tipoUtente.Docente, 11, DateTime.Now));

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            try
            {
                biblioteca.AggiungiPrestito(new CPrestito("Jimmy il fuoriclasse", tipoUtente.Studente, -67, DateTime.Now));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            biblioteca.RestituisciLibro(3);//restituisco il libro con id = 3;
            Console.WriteLine("LIBRI TITOLO(\"Albert Einstein\")\n" + biblioteca.CercaPrestitoPerLibro("Albert Einstein")); //utilizzo la funzione CercaPrestiti per cercare i prestiti di un determinato libro
            Console.WriteLine("\nDURATA MEDIA PRESTITI: " + biblioteca.DurataMediaPrestiti());
            Console.WriteLine("\nPRESTITI IN RITARDO : \n" + biblioteca.PrestitiInRitardo());
            int[] val = new int[3]; //dichiaro e inizializzo un array per contenere la quantità dei libri per categoria
            val = biblioteca.ContaprestitiPerCategoria();
            Console.WriteLine($"\nCATEGORIE : \nSTUDENTE = {val[0]}\nDOCENTE = {val[1]}\nESTRENO = {val[2]}"); //stampoi il numero di libri per categoria
            Console.WriteLine("\nIl libro più richiesto e' : "+ biblioteca.LibroPiuRichiesto()); //trovo il libro più richiesto

        }
    }
}
